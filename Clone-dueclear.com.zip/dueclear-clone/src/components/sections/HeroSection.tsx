"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <div className="relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 pb-24 pt-10 sm:pb-32 lg:flex lg:px-8 lg:py-40">
        <div className="mx-auto max-w-2xl lg:mx-0 lg:max-w-xl lg:pt-8">
          <div className="mt-24 sm:mt-32 lg:mt-16">
            <div className="inline-flex space-x-6">
              <span className="rounded-full bg-primary/10 px-3 py-1 text-sm font-semibold leading-6 text-primary ring-1 ring-inset ring-primary/10">
                What&apos;s new
              </span>
              <span className="inline-flex items-center space-x-2 text-sm font-medium leading-6 text-muted-foreground">
                <span>Just shipped v1.0</span>
              </span>
            </div>
          </div>
          <h1 className="mt-10 text-4xl font-bold tracking-tight text-foreground sm:text-6xl">
            Professional Invoicing Made Simple
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground">
            Create, manage, and track invoices effortlessly. Perfect for
            freelancers, small businesses, and enterprises.
          </p>
          <div className="mt-10 flex items-center gap-x-6">
            <Button asChild size="lg">
              <Link href="/signup">Start Free Trial</Link>
            </Button>
            <Button variant="ghost" size="lg">
              Learn more
            </Button>
          </div>
        </div>
        <div className="mt-16 flex-1 lg:mt-0">
          <div className="relative">
            <Image
              src="https://ext.same-assets.com/3201005138/3841008190.jpeg"
              alt="Dashboard screenshot"
              width={800}
              height={600}
              className="rounded-xl shadow-xl"
              priority
            />
          </div>
        </div>
      </div>
    </div>
  );
}
