"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckIcon } from "lucide-react";

export default function PricingSection() {
  const tiers = [
    {
      name: "Starter",
      price: "$15",
      description: "Perfect for freelancers and small businesses.",
      features: [
        "Up to 10 invoices per month",
        "Basic invoice templates",
        "Email support",
        "Export to PDF",
      ],
      cta: "Get started",
      highlighted: false,
    },
    {
      name: "Professional",
      price: "$30",
      description: "For growing businesses with more needs.",
      features: [
        "Unlimited invoices",
        "Custom templates",
        "Priority support",
        "Advanced analytics",
        "Multiple team members",
      ],
      cta: "Get started",
      highlighted: true,
    },
    {
      name: "Enterprise",
      price: "$99",
      description: "For large organizations requiring advanced features.",
      features: [
        "Everything in Professional",
        "Custom domain",
        "API access",
        "Dedicated account manager",
        "Custom integrations",
        "SLA guarantee",
      ],
      cta: "Get started",
      highlighted: false,
    },
  ];

  return (
    <div className="py-24 sm:py-32" id="pricing">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <h2 className="text-base font-semibold leading-7 text-primary">Pricing</h2>
          <p className="mt-2 text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Choose the right plan for you
          </p>
        </div>
        <p className="mx-auto mt-6 max-w-2xl text-center text-lg leading-8 text-muted-foreground">
          Start with our free trial. No credit card required.
        </p>

        <div className="isolate mx-auto mt-16 grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {tiers.map((tier) => (
            <Card key={tier.name} className="flex flex-col justify-between rounded-3xl p-8 ring-1 ring-muted xl:p-10">
              <div>
                <div className="flex items-center justify-between gap-x-4">
                  <h3 className="text-lg font-semibold leading-8 text-foreground">{tier.name}</h3>
                </div>
                <p className="mt-4 text-sm leading-6 text-muted-foreground">{tier.description}</p>
                <p className="mt-6 flex items-baseline gap-x-1">
                  <span className="text-4xl font-bold tracking-tight text-foreground">{tier.price}</span>
                  <span className="text-sm font-semibold leading-6 text-muted-foreground">/month</span>
                </p>
                <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-muted-foreground">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex gap-x-3">
                      <CheckIcon className="h-5 w-5 flex-none text-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              <Link href="/signup" className="mt-8">
                <Button className={tier.highlighted ? "w-full" : "w-full bg-background hover:bg-accent text-foreground border-border"} variant={tier.highlighted ? "default" : "outline"}>
                  {tier.cta}
                </Button>
              </Link>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
